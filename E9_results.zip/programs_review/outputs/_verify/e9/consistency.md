# E9 の一致の確認（実験指示E9.md 2節）

実施日：2026-11-23．本PC：NVIDIA RTX PRO 6000 Blackwell Max-Q Workstation Edition（ドライバ 582.08），Intel Xeon w7-3565X，WSL2（Linux 6.18.33.2）．

```bash
cd programs_review/programs/ex005_appb_imagewoof_resnet18_layernorm
../../../.venv_pytorch/bin/python train.py --batch-sizes 512 --methods ASAI_SVRG --inner-starts snapshot \
    --seeds 0 --epochs 3 --output-root ../../outputs/_verify/e9 --workers 1
```

比較先：`outputs/ex005_appb_imagewoof_resnet18_layernorm/ASAI_SVRG/inner_snapshot_lr0.001_bs512_lambda0.0005_epochs505/0/log.json`（既存のシード0）の最初の4点．

## 1. 実行環境（`config.json` の `environment`）

| 項目 | 既存のシード0 | 今回 |
|---|---|---|
| torch | 2.11.0+cu128 | 2.11.0+cu128 |
| torchvision | 0.26.0+cu128 | 0.26.0+cu128 |
| CUDA | 12.8 | 12.8 |
| cuDNN | 91900 | 91900 |
| GPU | NVIDIA RTX PRO 6000 Blackwell Max-Q Workstation Edition | 同左 |
| Pillow | 13.0.0 | 13.0.0 |

違いは無い．

## 2. 値の比較

| エポック | 指標 | 既存 | 今回 | 相対差 |
|---:|---|---:|---:|---:|
| 0 | `oracle_calls` | 0 | 0 | 0（一致） |
| 0 | `train_loss` | 4.4551721304473455 | 4.4551721304473455 | 0 |
| 0 | `test_accuracy` | 0.05701196233138203 | 0.05701196233138203 | 0 |
| 0 | `approx_error` | 116.58558907639235 | 116.58558907639235 | 0 |
| 1 | `oracle_calls` | 18050 | 18050 | 0（一致） |
| 1 | `train_loss` | 4.455173211454355 | 4.455173211454355 | 0 |
| 1 | `test_accuracy` | 0.05701196233138203 | 0.05701196233138203 | 0 |
| 1 | `approx_error` | 0.0013137801449869535 | 0.0013137801449869535 | 0 |
| 2 | `oracle_calls` | 36100 | 36100 | 0（一致） |
| 2 | `train_loss` | 4.236528958825193 | 4.236528958825193 | 0 |
| 2 | `test_accuracy` | 0.10435225477986859 | 0.10435225477986859 | 0 |
| 2 | `approx_error` | 0.1498300891601616 | 0.1498300891601616 | 0 |
| 3 | `oracle_calls` | 54150 | 54150 | 0（一致） |
| 3 | `train_loss` | 4.213856664853083 | 4.213856664853083 | 0 |
| 3 | `test_accuracy` | 0.11453296093577858 | 0.11453296093577858 | 0 |
| 3 | `approx_error` | 0.006116598743449941 | 0.006116598743449941 | 0 |

**判定：合格．** 全ての値がビット単位で一致した（基準は `oracle_calls` の一致と相対差 $ 10^{-3} $ 以下）．

## 3. メモリの使用量（並列数1，3エポック）

| 項目 | 値 |
|---|---|
| GPU の `memory.used`（`nvidia-smi -l 2`） | 待機時 682 MiB，最大 23,183 MiB（1プロセスで約22.5 GB．総量 97,887 MiB） |
| 最大常駐メモリ（`/usr/bin/time -v`） | 9.4 GB（ImageWoof のキャッシュの `numpy.memmap` のページを含む．総量 125 GB） |
| 実時間 | 1分26秒（データの読み込みと評価を含む） |
